

const baseColor ={
    // color : "#236DB7",
    // bg: "white", 
    // colorFont: "#236DB7",
    // colorFont2: "#ffffff",
    // footerColor: "#ffffff",
    // headerColor: "#FFffff",
    
    //color principal
     color : "#236DB7",
    // //color fondo principal
    bg: "#fff", 
    // //color fondo secundario
     bg2: "#ededed",
    // //color de fuente primario 
     colorFont: "#236DB7",
    //color fuente secundario(botones)
     colorFont2: "#FFffff",
    //color de barra de navegacion inferior
     footerColor: "#FFffff",
     headerColor: "#FFffff",
     footerIcon: "#5A5A5A",
     footerIconBg: "#C8C8C8",
     footerIconSelect: "#236DB7",
  
  }
  
  
  
  
  
  export default baseColor;