

const URL ={
    // BASE_URL : "https://v-csoft.com/leappi/"
     BASE_URL : "http://sdiqro.store/"
  }
  
  
  
  
  
  export default URL;