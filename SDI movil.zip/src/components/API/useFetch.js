import {useState, useEffect} from 'react';




export const URL ={
    // BASE_URL : "https://v-csoft.com/leappi/"
     BASE_URL : "http://sdiqro.store/api/"
  }