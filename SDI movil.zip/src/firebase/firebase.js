import firebase from 'firebase';

const firebaseConfig = {
    apiKey: "AIzaSyAV-mSUk-r-8GIPJ14HPLVAsPdycThfLXc",
    authDomain: "sdi-impresiones-digitales.firebaseapp.com",
    projectId: "sdi-impresiones-digitales",
    storageBucket: "sdi-impresiones-digitales.appspot.com",
    messagingSenderId: "843305891490",
    appId: "1:843305891490:web:27c9654b18eefc931849fb"
  };

  firebase.initializeApp(firebaseConfig);