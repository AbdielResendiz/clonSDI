const colors={
    azul     : "#00BAEA", //azul claro, el principal
    rosa     : "#FE308E",
    negro    : "#292926",
    amarillo : "#FAEA00",
    gris     : "#6C6C6C",
    blanco   : "#FFFFFF",
    grisbg : "#fafafa",
    grisclaro: "#f0f0f0"


}
export default colors;